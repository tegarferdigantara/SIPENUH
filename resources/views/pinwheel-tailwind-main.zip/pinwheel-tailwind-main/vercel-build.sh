#!/bin/bash

# install dependencies
echo "Installing dependencies..."
npm install

# generate demo
echo "Generating demo site..."
npm run deploy